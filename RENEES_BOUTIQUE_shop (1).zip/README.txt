RENEE'S BOUTIQUE - Photo Upload Shop

1. Open index.html in a browser.
2. Select a product photo.
3. Enter product name and price.
4. Choose a category.
5. Tap Add Product.
6. Customers can tap Order on WhatsApp.

Products are saved in the browser on that device. This is a starter shop template; for a public online store with photos shared to all customers, the next step is to publish it and connect a proper product database/storage.
